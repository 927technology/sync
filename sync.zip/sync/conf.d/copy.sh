#!/bin/bash


for line in `cat passwords`; do
	#get range name
	range=`echo ${line} | awk -F "," '{print $1}' | awk -F "_" '{print $1}'`
	id=`echo ${range} | sed 's/cs//g'`

	#get device name
	device=`echo ${line} | awk -F "," '{print $1}' | awk -F "_" '{print $2}'`

	#get password
	pass=`echo ${line} | awk -F "," '{print $2}'`

	echo $range
	echo $id
	echo $device
	echo $pass

	if [ ! -d cyfun_${range} ]; then
		mkdir -p cyfun_${range}
	fi

	cp -R cyfun_cs00/router.cfg cyfun_${range}/
	cp -R cyfun_cs00/switch-left.cfg cyfun_${range}/
	cp -R cyfun_cs00/switch-right.cfg cyfun_${range}/
	cp -R cyfun_cs00/rescue.cfg cyfun_${range}/
	cp -R cyfun_cs00/host.address cyfun_${range}/
	cp -R cyfun_cs00/host.login cyfun_${range}/
	cp -R cyfun_cs00/host.pass cyfun_${range}/
	cp -R cyfun_cs00/kadmin.pass cyfun_${range}/
	cp -R cyfun_cs00/instructor.pass cyfun_${range}/

	#copy imaging configs
	rm -rf cyfun_${range}/imaging
	cp -R cyfun_cs00/imaging cyfun_${range}/

	#copy tshoot configs
	rm -rf cyfun_${range}/tshoot*
	cp -R cyfun_cs00/tshoot01 cyfun_${range}/
	cp -R cyfun_cs00/tshoot02 cyfun_${range}/
	cp -R cyfun_cs00/tshoot03 cyfun_${range}/
	cp -R cyfun_cs00/tshoot04 cyfun_${range}/
	cp -R cyfun_cs00/tshoot05 cyfun_${range}/
	cp -R cyfun_cs00/tshoot06 cyfun_${range}/
	cp -R cyfun_cs00/tshoot07 cyfun_${range}/
	cp -R cyfun_cs00/tshoot08 cyfun_${range}/
	cp -R cyfun_cs00/tshoot09 cyfun_${range}/
	cp -R cyfun_cs00/tshoot10 cyfun_${range}/
	cp -R cyfun_cs00/tshoot11 cyfun_${range}/

	#set ranges specific variables
	sed -i 's/cs01/'${range}'/g' cyfun_${range}/router.cfg
	sed -i 's/cs01/'${range}'/g' cyfun_${range}/switch-left.cfg
	sed -i 's/cs01/'${range}'/g' cyfun_${range}/switch-right.cfg
	sed -i 's/.101/.1'${id}'/g' cyfun_${range}/host.address
	sed -i 's/.101/.1'${id}'/g' cyfun_${range}/imaging/router.cfg

	echo ${pass} > cyfun_${range}/${device}.pass
echo ------

	echo cyfun_${range}/${device}.pass
	cat cyfun_${range}/${device}.pass


done
